
default_action :create

actions :create

attribute :name, :kind_of => String, :name_attribute => true, :required => true
