nodejs-setup CHANGELOG
======================

This file is used to list changes made in each version of the nodejs-setup cookbook.

0.1.8
-----
- [huytran] - Fix bug of npm packages install

0.1.1
-----
- [huytran] - Update readme & support rhel, fedora os

0.1.0
-----
- [huytran] - Initial release of nodejs-setup

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
