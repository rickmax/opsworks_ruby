# Poise-Monit-Compat Changelog

## v1.0.0

* Initial release.

## v0.7.5 and Earlier

* Can be found in the [old `monit` cookbook](https://github.com/apsoto/monit/).
