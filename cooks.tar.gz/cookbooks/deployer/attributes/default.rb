default['deployer']['user']     = 'deploy'
default['deployer']['group']    = 'deploy'
default['deployer']['home']     = "/home/#{default['deployer']['user']}"
