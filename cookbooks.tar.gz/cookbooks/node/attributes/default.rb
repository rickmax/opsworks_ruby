default[:node][:revision]      = "HEAD"
default[:node][:repo_url]      = "https://github.com/joyent/node.git"
default[:node][:user]          = "nodejs"
default[:node][:packages]      = []
